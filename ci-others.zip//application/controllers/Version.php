<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Version extends BP_Controller
{

    public function index()
    {
        echo "1.0";
    }
}
