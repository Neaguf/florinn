<?php
/**
 * Created by PhpStorm.
 * User: danadrian
 * Date: 18/02/18
 * Time: 12:41
 */

class AuthHelper {
	public $NotLogged = true;
}